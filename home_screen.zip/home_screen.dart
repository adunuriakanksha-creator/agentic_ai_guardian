import 'package:geolocator/geolocator.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'emergency_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isMonitoring = true;
  String _safetyStatus = 'Safe';
  Color _statusColor = const Color(0xFF2E7D32);
  Color _statusBg = const Color(0xFFE8F5E9);

  int _heartRate = 72;
  bool _voiceDistress = false;
  bool _routeDeviation = false;
  bool _motionAnomaly = false;
  String _heartStatus = 'NORMAL';
  int _signalCount = 0;
  int _confidence = 0;
  int _countdown = 30;
  String _currentLocation = 'Getting location...';

  // ── Smart Agent fields ───────────────────────
  String _agentDecision = '';
  String _agentUrgency = '';
  List<dynamic> _alertList = [];
  List<dynamic> _nearbyHelp = [];
  bool _smartSosSent = false;

  Timer? _monitorTimer;
  Timer? _countdownTimer;

  final String backendUrl = 'http://127.0.0.1:5000';

  @override
  void initState() {
    super.initState();

    _getLocation().then((loc) {
      setState(() => _currentLocation = loc);
    });

    _monitorTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (_isMonitoring) _analyzeAllSignals();
    });

    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          if (_countdown > 0) _countdown--;
        });
      }
    });

    Future.delayed(const Duration(seconds: 30), () {
      if (mounted && _isMonitoring) {
        setState(() {
          _heartRate = 145;
          _voiceDistress = true;
          _routeDeviation = true;
          _motionAnomaly = true;
          _heartStatus = 'DANGER';
        });
        _analyzeAllSignals();

        Future.delayed(const Duration(seconds: 10), () {
          if (mounted) {
            setState(() {
              _heartRate = 72;
              _voiceDistress = false;
              _routeDeviation = false;
              _motionAnomaly = false;
              _safetyStatus = 'Safe';
              _statusColor = const Color(0xFF2E7D32);
              _statusBg = const Color(0xFFE8F5E9);
              _signalCount = 0;
              _confidence = 0;
              _heartStatus = 'NORMAL';
              _countdown = 30;
              _agentDecision = '';
              _agentUrgency = '';
              _alertList = [];
              _nearbyHelp = [];
              _smartSosSent = false;
            });
            _countdownTimer?.cancel();
            _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
              if (mounted) {
                setState(() {
                  if (_countdown > 0) _countdown--;
                });
              }
            });
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _monitorTimer?.cancel();
    _countdownTimer?.cancel();
    super.dispose();
  }

  Future<String> _getLocation() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever) {
        return '17.3850,78.4867';
      }
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      return '${position.latitude},${position.longitude}';
    } catch (e) {
      return '17.3850,78.4867';
    }
  }

  Future<void> _analyzeAllSignals() async {
    try {
      final location = await _getLocation();
      setState(() => _currentLocation = location);

      final response = await http.post(
        Uri.parse('$backendUrl/analyze'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'bpm': _heartRate,
          'voice_distress': _voiceDistress,
          'route_deviation': _routeDeviation,
          'motion_anomaly': _motionAnomaly,
          'location': location,
        }),
      );

      final data = jsonDecode(response.body);
      final int signalCount = data['signal_count'];
      final bool autoSos = data['auto_sos_sent'];
      final String threatLevel = data['threat_level'];
      final int confidence = data['confidence'];

      setState(() {
        _signalCount = signalCount;
        _confidence = confidence;
        if (threatLevel == 'HIGH') {
          _safetyStatus = 'DANGER DETECTED';
          _statusColor = const Color(0xFFC62828);
          _statusBg = const Color(0xFFFFEBEE);
        } else if (threatLevel == 'MEDIUM') {
          _safetyStatus = 'Warning';
          _statusColor = const Color(0xFFE65100);
          _statusBg = const Color(0xFFFFF3E0);
        } else {
          _safetyStatus = 'Safe';
          _statusColor = const Color(0xFF2E7D32);
          _statusBg = const Color(0xFFE8F5E9);
        }
      });

      // ── Run Smart Agent when confidence >= 85 ──
      if (confidence >= 85) {
        await _runSmartAgent(location, confidence);
      }

      if (autoSos && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🚨 AUTO SOS SENT! Confidence: $confidence%'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } catch (e) {
      print('Analysis error: $e');
    }
  }

  Future<void> _runSmartAgent(String location, int confidence) async {
    try {
      final smartResponse = await http.post(
        Uri.parse('$backendUrl/smart-sos'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'bpm': _heartRate,
          'voice_distress': _voiceDistress,
          'route_deviation': _routeDeviation,
          'motion_anomaly': _motionAnomaly,
          'confidence': confidence,
          'location': location,
        }),
      );

      final smartData = jsonDecode(smartResponse.body);

      setState(() {
        _agentDecision = smartData['agent_decision'] ?? '';
        _agentUrgency  = smartData['urgency'] ?? '';
        _alertList     = smartData['alert_list'] ?? [];
        _nearbyHelp    = smartData['nearby_help'] ?? [];
        _smartSosSent  = smartData['sms_sent'] ?? false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '🤖 SMART SOS! Alerted ${_alertList.length} contact(s) intelligently!',
            ),
            backgroundColor: Colors.deepPurple,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } catch (e) {
      print('Smart agent error: $e');
    }
  }

  Future<void> _sendSOS() async {
    try {
      final location = await _getLocation();
      await http.post(
        Uri.parse('$backendUrl/sos'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'location': location,
          'bpm': _heartRate,
        }),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('🚨 SOS Sent to emergency contact!'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('SOS triggered!'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _simulateThreat() async {
    setState(() {
      _heartRate = 145;
      _voiceDistress = true;
      _routeDeviation = true;
      _motionAnomaly = true;
      _heartStatus = 'DANGER';
    });
    await _analyzeAllSignals();
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted) {
        setState(() {
          _heartRate = 72;
          _voiceDistress = false;
          _routeDeviation = false;
          _motionAnomaly = false;
          _safetyStatus = 'Safe';
          _statusColor = const Color(0xFF2E7D32);
          _statusBg = const Color(0xFFE8F5E9);
          _signalCount = 0;
          _confidence = 0;
          _heartStatus = 'NORMAL';
          _agentDecision = '';
          _agentUrgency = '';
          _alertList = [];
          _nearbyHelp = [];
          _smartSosSent = false;
        });
      }
    });
  }

  Color get _heartColor {
    if (_heartStatus == 'DANGER') return Colors.red;
    if (_heartStatus == 'STRESS') return Colors.orange;
    return Colors.green;
  }

  Color get _confidenceColor {
    if (_confidence >= 85) return Colors.red;
    if (_confidence >= 50) return Colors.orange;
    return Colors.green;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FF),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header ───────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('SafeGuard',
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF1565C0))),
                      Text('Stay safe, always.',
                          style: TextStyle(fontSize: 13, color: Colors.grey)),
                    ],
                  ),
                  const CircleAvatar(
                    backgroundColor: Color(0xFF1565C0),
                    child: Icon(Icons.shield, color: Colors.white),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ── LOCATION CARD ────────────────────────
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
                ),
                child: Row(
                  children: [
                    const Icon(Icons.location_on, color: Color(0xFF1565C0), size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Location: $_currentLocation',
                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              // ── COUNTDOWN ───────────────────────────
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _countdown > 0 ? const Color(0xFFFFF8E1) : const Color(0xFFFFEBEE),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _countdown > 0 ? Colors.orange : Colors.red),
                ),
                child: Row(
                  children: [
                    Icon(_countdown > 0 ? Icons.timer : Icons.warning,
                        color: _countdown > 0 ? Colors.orange : Colors.red),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _countdown > 0
                            ? 'AI auto-detecting threats in $_countdown sec...'
                            : 'AI detected danger! SOS sent!',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: _countdown > 0 ? Colors.orange : Colors.red,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ── STATUS CARD ──────────────────────────
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: _statusBg,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _statusColor.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(
                      _safetyStatus == 'Safe' ? Icons.check_circle : Icons.warning_amber_rounded,
                      color: _statusColor, size: 40,
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Status: $_safetyStatus',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _statusColor)),
                          Text(_isMonitoring ? 'SafeGuard AI is active' : 'Monitoring paused',
                              style: const TextStyle(fontSize: 13, color: Colors.grey)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ── HEART RATE CARD ──────────────────────
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
                ),
                child: Row(
                  children: [
                    Icon(Icons.favorite, color: _heartColor, size: 32),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('$_heartRate BPM',
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: _heartColor)),
                        Text('Heart Rate: $_heartStatus',
                            style: TextStyle(fontSize: 12, color: _heartColor)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ── SIGNAL CARDS ─────────────────────────
              const Text('Live Signals', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Row(
                children: [
                  _signalCard(Icons.mic, 'Voice', _voiceDistress),
                  const SizedBox(width: 10),
                  _signalCard(Icons.map, 'Route', _routeDeviation),
                  const SizedBox(width: 10),
                  _signalCard(Icons.directions_walk, 'Motion', _motionAnomaly),
                ],
              ),
              const SizedBox(height: 16),

              // ── CONFIDENCE LEVEL ─────────────────────
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('AI Confidence Level',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _confidenceColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            _confidence >= 85 ? '🚨 DANGER'
                                : _confidence >= 50 ? '⚠️ WARNING' : '✅ SAFE',
                            style: TextStyle(color: _confidenceColor, fontWeight: FontWeight.bold, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: LinearProgressIndicator(
                        value: _confidence / 100,
                        minHeight: 14,
                        backgroundColor: Colors.grey.shade200,
                        valueColor: AlwaysStoppedAnimation<Color>(_confidenceColor),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('$_confidence% confidence',
                            style: TextStyle(fontSize: 13, color: _confidenceColor, fontWeight: FontWeight.bold)),
                        Text(
                          _confidence >= 85 ? 'SOS sent automatically!'
                              : _confidence >= 50 ? 'Monitoring closely...' : 'All signals normal',
                          style: TextStyle(fontSize: 12, color: _confidenceColor),
                        ),
                      ],
                    ),
                    if (_confidence >= 85) ...[
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.warning, color: Colors.red, size: 16),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '$_signalCount danger signals triggered auto SOS!',
                                style: const TextStyle(color: Colors.red, fontSize: 12, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ── PURPLE SMART AGENT CARD ──────────────
              if (_agentDecision.isNotEmpty) ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.deepPurple.shade50,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.deepPurple.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Row(
                        children: [
                          const Icon(Icons.smart_toy, color: Colors.deepPurple, size: 20),
                          const SizedBox(width: 8),
                          const Text('SafeGuard Smart Agent',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: _agentUrgency == 'HIGH' ? Colors.red : Colors.orange,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              _agentUrgency,
                              style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),

                      // Agent decision text
                      Text(_agentDecision,
                          style: const TextStyle(fontSize: 12, color: Colors.deepPurple)),
                      const SizedBox(height: 10),

                      // Alerted contacts
                      if (_alertList.isNotEmpty) ...[
                        const Text('Alerted contacts:',
                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                        const SizedBox(height: 6),
                        ..._alertList.map((contact) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Row(
                            children: [
                              const Icon(Icons.person_pin, size: 16, color: Colors.deepPurple),
                              const SizedBox(width: 6),
                              Text(
                                '${contact['name']} — ${contact['role']} (${contact['availability']}% available)',
                                style: const TextStyle(fontSize: 12, color: Colors.deepPurple),
                              ),
                            ],
                          ),
                        )),
                        const SizedBox(height: 8),
                      ],

                      // Nearby help
                      if (_nearbyHelp.isNotEmpty) ...[
                        const Text('Nearby help found:',
                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                        const SizedBox(height: 6),
                        ..._nearbyHelp.map((place) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Row(
                            children: [
                              const Icon(Icons.local_hospital, size: 16, color: Colors.deepPurple),
                              const SizedBox(width: 6),
                              Text(place['name'] ?? '',
                                  style: const TextStyle(fontSize: 12, color: Colors.deepPurple)),
                            ],
                          ),
                        )),
                      ],

                      // SMS sent confirmation
                      if (_smartSosSent) ...[
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.deepPurple.shade100,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.deepPurple, size: 16),
                              SizedBox(width: 6),
                              Text('Smart SMS sent successfully!',
                                  style: TextStyle(color: Colors.deepPurple, fontSize: 12, fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],

              // ── MONITORING TOGGLE ────────────────────
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Row(children: [
                      Icon(Icons.shield, color: Color(0xFF1565C0)),
                      SizedBox(width: 10),
                      Text('SafeGuard Monitoring', style: TextStyle(fontWeight: FontWeight.w500, fontSize: 15)),
                    ]),
                    Switch(
                      value: _isMonitoring,
                      onChanged: (v) => setState(() => _isMonitoring = v),
                      activeThumbColor: const Color(0xFF1565C0),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // ── SOS BUTTON ───────────────────────────
              GestureDetector(
                onTap: _sendSOS,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 22),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD32F2F),
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.3), blurRadius: 16, spreadRadius: 2)],
                  ),
                  child: const Column(children: [
                    Icon(Icons.sos, color: Colors.white, size: 40),
                    SizedBox(height: 6),
                    Text('TAP FOR SOS',
                        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2)),
                    Text('Tap to send emergency alert',
                        style: TextStyle(color: Color(0xFFFFCDD2), fontSize: 12)),
                  ]),
                ),
              ),
              const SizedBox(height: 20),

              // ── RECENT ALERTS ────────────────────────
              const Text('Recent Alerts', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _alertTile(Icons.directions_walk, 'Route deviation detected', '2 min ago', Colors.orange),
              const SizedBox(height: 8),
              _alertTile(Icons.mic, 'Voice analysis: Normal', '15 min ago', Colors.green),
              const SizedBox(height: 8),
              _alertTile(Icons.shield, 'SafeGuard check-in complete', '30 min ago', Colors.blue),
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: _simulateThreat,
                icon: const Icon(Icons.play_circle_outline),
                label: const Text('Simulate ALL threat signals (demo)'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _signalCard(IconData icon, String label, bool isDanger) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isDanger ? Colors.red.shade50 : Colors.green.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: isDanger ? Colors.red.shade200 : Colors.green.shade200),
        ),
        child: Column(
          children: [
            Icon(icon, color: isDanger ? Colors.red : Colors.green, size: 24),
            const SizedBox(height: 4),
            Text(label,
                style: TextStyle(fontSize: 11, color: isDanger ? Colors.red : Colors.green, fontWeight: FontWeight.w500)),
            Text(isDanger ? 'ALERT' : 'OK',
                style: TextStyle(fontSize: 10, color: isDanger ? Colors.red : Colors.green)),
          ],
        ),
      ),
    );
  }

  Widget _alertTile(IconData icon, String title, String time, Color color) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)],
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(child: Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500))),
        Text(time, style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ]),
    );
  }
}